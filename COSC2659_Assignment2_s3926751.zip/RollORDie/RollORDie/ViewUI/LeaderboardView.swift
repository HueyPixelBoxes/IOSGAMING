//
//  LeaderboardView.swift
//  RollORDie
//
//  Created by Huy Pham Quang on 29/08/2023.
//
/* RMIT University Vietnam Course: COSC2659 iOS Development
 Semester: 2023B
 Assessment: Assignment 2
 Author: Pham Quang Huy
 ID: s3926751
 Created date: 1/9/2023
 Last modified: 7/9/2023
 Acknowledgement: Courses' lectures & tutorials, minor details from online resources from stackoverflow.com, hackingwithswift.com, ... etc
 */
import SwiftUI
import AVFoundation
struct LeaderboardView: View {
    @State var currentPage = Page.Board
    var body: some View {
        VStack{ // view explain mechanics
            if currentPage == .Board{ // for leader board
                Button{
                    currentPage = .Menu
                    Sounds.play(sound:"blipSelect", type: "mp3", loop: 0)
                }label:{
                    Text("Return").font(.custom("Sol Schori Bold", size: 20)) //return button with sound
                }.buttonStyle(.plain).padding(10)
            }
            else{
                MenuView()
            }
        }
    }
}

struct LeaderboardView_Previews: PreviewProvider {
    static var previews: some View {
        LeaderboardView()
    }
}
