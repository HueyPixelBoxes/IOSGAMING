//
//  DeathView.swift
//  RollORDie
//
//  Created by Huy Pham Quang on 29/08/2023.
//
/* RMIT University Vietnam Course: COSC2659 iOS Development
 Semester: 2023B
 Assessment: Assignment 2
 Author: Pham Quang Huy
 ID: s3926751
 Created date: 1/9/2023
 Last modified: 7/9/2023
 Acknowledgement: Courses' lectures & tutorials, minor details from online resources from stackoverflow.com, hackingwithswift.com, ... etc
 */

import SwiftUI
import AVFoundation
struct DeathView: View {
    @ObservedObject var setting : GameViewModel // extract object from setting
    @State private var currentPage = Page.Death //current page
    var body: some View {
        VStack{
            // death image
            // go to menu, save game
            VStack{
                Text("").onAppear{
                    Sounds.play(sound: "Menu", type: "mp3", loop: -1)// play background sound
                }
                if currentPage == .Death{ // if in death view
                    Image("death").resizable().scaledToFit().frame(width: 300)
                    Text("YOU ARE DEAD").font(.custom("Sol Schori Bold", size: 40))
                    Text("\(setting.win)").font(.custom("Sol Schori Bold", size: 35))//display score
                    Button{
                        currentPage = .Menu //go to menu
                        Sounds.play(sound:"blipSelect", type: "mp3", loop: 0)
                    }label:{
                            Text("Return to menu").font(.custom("Sol Schori Bold", size: 30))
                    
                    }.buttonStyle(.plain).padding(20)
                    Button{
                        currentPage = .Game// play again
                        Sounds.play(sound:"blipSelect", type: "mp3", loop: 0)
                    }label:{
                        
                            Text("Play Again").font(.custom("Sol Schori Bold", size: 30))
                    }.buttonStyle(.plain)
                }
                else{
                    switch currentPage { // for transition
                    case .Menu:
                        MenuView()
                    case .Game:
                        SettingView()
                    default:
                        DeathView(setting: setting)
                    }
                }
            }.onAppear{
                Sounds.play(sound: "death", type: "mp3", loop: 0)// play deaeth sound when die
            }
        }
    }
}
