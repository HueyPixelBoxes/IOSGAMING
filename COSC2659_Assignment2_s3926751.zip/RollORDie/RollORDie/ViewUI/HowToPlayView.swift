//
//  HowToPlayView.swift
//  RollORDie
//
//  Created by Huy Pham Quang on 29/08/2023.
//
/* RMIT University Vietnam Course: COSC2659 iOS Development
 Semester: 2023B
 Assessment: Assignment 2
 Author: Pham Quang Huy
 ID: s3926751
 Created date: 1/9/2023
 Last modified: 7/9/2023
 Acknowledgement: Courses' lectures & tutorials, minor details from online resources from stackoverflow.com, hackingwithswift.com, ... etc
 */
import SwiftUI
import AVFoundation
struct HowToPlayView: View {
    @State private var currentPage = Page.Guide // current page variable
    var body: some View {
        VStack{ // view explain mechanics
                if currentPage == .Guide{
                    HStack{
                        Button{
                            currentPage = .Menu//to page menu
                            Sounds.play(sound: "blipSelect", type: "mp3", loop: 0)//play sound
                        }label:{
                            Text("Return").font(.custom("Sol Schori Bold", size: 20))
                        }.buttonStyle(.plain).padding(10)
                        Spacer()
                    }
                    Spacer()
                    Image("theme").resizable().scaledToFit().frame(width: 400)
                    Text("Tap 'Roll' to roll the dice Tap again for rerolls until 0 Check result use 'Check' Win game and gain coin (score) Or until Lives turn 0 Play risky for coins Or safe and spent all")
                        .font(.custom("Sol Schori Bold", size: 20))
                        .padding(10).multilineTextAlignment(.center).lineSpacing(25)// rule + guide at the end
                    Text(" Your CHOICE")
                        .font(.custom("Sol Schori Bold", size: 40)).padding(10).multilineTextAlignment(.center)
                }
                else{
                    MenuView()
                }
        }
        
        }
    }

struct HowToPlayView_Previews: PreviewProvider {
    static var previews: some View {
        HowToPlayView()
    }
}
