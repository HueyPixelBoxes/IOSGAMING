//
//  SettingView.swift
//  RollORDie
//
//  Created by Huy Pham Quang on 05/09/2023.
//
/* RMIT University Vietnam Course: COSC2659 iOS Development
 Semester: 2023B
 Assessment: Assignment 2
 Author: Pham Quang Huy
 ID: s3926751
 Created date: 1/9/2023
 Last modified: 7/9/2023
 Acknowledgement: Courses' lectures & tutorials, minor details from online resources from stackoverflow.com, hackingwithswift.com, ... etc
 */
import SwiftUI
import AVFoundation
struct SettingView: View { // This is the Setting View requried
    @StateObject var setting = GameViewModel() // create object view model for sharing accross the app
    @State private var isPressed = false // variable for button pressed and transit view
    @State private var name = "" // name for text field
    var body: some View {
        VStack{
            if !isPressed { //for transit view to real gameplay
                Image("theme").resizable().scaledToFit().frame(width: 400)
                Text("Choose Difficulties").font(.custom("Sol Schori Bold", size: 40))
                    .multilineTextAlignment(.center).padding(20)
                TextField( "your name, please", text: $name)
                    .font(.custom("Sol Schori Bold", size: 20)).multilineTextAlignment(.center)
                Text("Each define lives, rerolls and challenge")
                    .font(.custom("Sol Schori Bold", size: 20)).padding(20)
                    .multilineTextAlignment(.center)
                VStack{
                    Button{
                        setting.settingCreate(settingName: "Childplay") //set setting for game
                        Sounds.play(sound: "blipSelect", type: "mp3", loop: 0)//button sound
                        isPressed = true
                    }label:{
                            Text("Childplay").font(.custom("Sol Schori Bold", size: 30))
                            .padding(10)
                    }.buttonStyle(.plain)
                    Button{
                        setting.settingCreate(settingName: "Dime&Dozen")
                        Sounds.play(sound: "blipSelect", type: "mp3", loop: 0)
                        isPressed = true
                    }label:{
                            Text("Dime&Dozen").font(.custom("Sol Schori Bold", size: 30))
                            .padding(10)
                    }.buttonStyle(.plain)
                    Button{
                        setting.settingCreate(settingName: "Gambler")
                        Sounds.play(sound: "blipSelect", type: "mp3", loop: 0)
                        isPressed = true
                    }label:{
                            Text("Gambler").font(.custom("Sol Schori Bold", size: 30))
                            .padding(10)
                    }.buttonStyle(.plain)
                }
            }
            else
            {
                GameView(setting: setting)//defaukt view
            }
        }
    }
}

struct SettingView_Previews: PreviewProvider {
    static var previews: some View {
        SettingView().environmentObject(GameViewModel())
    }
}
