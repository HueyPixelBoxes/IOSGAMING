//
//  MenuView.swift
//  RollORDie
//
//  Created by Huy Pham Quang on 29/08/2023.
//
/* RMIT University Vietnam Course: COSC2659 iOS Development
 Semester: 2023B
 Assessment: Assignment 2
 Author: Pham Quang Huy
 ID: s3926751
 Created date: 1/9/2023
 Last modified: 7/9/2023
 Acknowledgement: Courses' lectures & tutorials, minor details from online resources from stackoverflow.com, hackingwithswift.com, ... etc
 */
import SwiftUI
import AVFoundation

enum Page{ // enumaratoin for 4 PAGE
    case Menu
    case Game
    case Guide
    case Board
    case Death
}

struct MenuView: View {
    @State private var currentPage = Page.Menu //STORE STAGE
    
    var body: some View {
        VStack{
            if currentPage == .Menu{ // if in menu
                Text("").onAppear{
                    Sounds.play(sound: "Menu", type: "mp3", loop: -1)//play soundtrack on backgorund
                }
                    Text("ROLL FOR DIME")
                        .font(.custom("Sol Schori Bold", size: 90)).multilineTextAlignment(.center).padding(20)
                    Button{
                        currentPage = .Game//transit to game view
                        Sounds.play(sound: "blipSelect", type: "mp3", loop: 0)//button sound
                    } label:{
                        ZStack{
                            Text("Game").font(.custom("Sol Schori Bold", size: 40))
                        }
                    }.buttonStyle(.plain).padding(20)

                    Button{
                        currentPage = .Guide//transit to guide
                        Sounds.play(sound:"blipSelect", type: "mp3", loop: 0)

                    } label:{
                            Text("How To Play").font(.custom("Sol Schori Bold", size: 40))
                    }.buttonStyle(.plain).padding(20)

                    Button{
                        currentPage = .Board // transit to leaderboard
                        Sounds.play(sound: "blipSelect", type: "mp3", loop: 0)
                    } label:{
                        
                            Text("LeaderBoard").font(.custom("Sol Schori Bold", size: 40))
                        
                    }.buttonStyle(.plain).padding(20)
            }
            else{
                switch currentPage {//check for currentPage, if it match then swtich to that view
                case .Game:
                    SettingView()
                case .Guide:
                    HowToPlayView()
                case .Board:
                    LeaderboardView()
                default:
                    MenuView()
                }
                
            }
        }
        
    }
}

struct MenuView_Previews: PreviewProvider {
    static var previews: some View {
        MenuView()
    }
}
