//
//  Sound.swift
//  RollORDie
//
//  Created by Huy Pham Quang on 07/09/2023.
//

import Foundation
import AVFoundation
/* RMIT University Vietnam Course: COSC2659 iOS Development
 Semester: 2023B
 Assessment: Assignment 2
 Author: Pham Quang Huy
 ID: s3926751
 Created date: 1/9/2023
 Last modified: 7/9/2023
 Acknowledgement: Courses' lectures & tutorials, minor details from online resources from stackoverflow.com, hackingwithswift.com, ... etc
 */
class Sounds{ // for playing sounds
    static var audioPlayer: AVAudioPlayer? // variable initialized

    static func play(sound: String, type: String, loop : Int) { // static called anywhere
        if let path = Bundle.main.path(forResource: sound, ofType: type) { // try using bunder path then try set sharing mode and ambience mode for sound
           do {
               //Doesn't stop background music
               try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.ambient, mode: .default, options: .mixWithOthers)
               try AVAudioSession.sharedInstance().setActive(true)
               //Load & play sound
               audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path)) // get content - mp3 file
               audioPlayer?.numberOfLoops = loop // check if loop or not, if -1 loop forever, loop = 0 then onl play once
               audioPlayer?.play()// p[lay audio
           } catch {
               print("Error playing sound")
          }
        }
    }
}
