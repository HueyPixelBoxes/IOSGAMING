//
//  GameView.swift
//  RollORDie
//
//  Created by Huy Pham Quang on 29/08/2023.
//
/* RMIT University Vietnam Course: COSC2659 iOS Development
 Semester: 2023B
 Assessment: Assignment 2
 Author: Pham Quang Huy
 ID: s3926751
 Created date: 1/9/2023
 Last modified: 7/9/2023
 Acknowledgement: Courses' lectures & tutorials, minor details from online resources from stackoverflow.com, hackingwithswift.com, ... etc
 */
import SwiftUI
import AVFoundation
struct GameView: View {
    @ObservedObject var setting : GameViewModel
    @State private var appear = false
    var body: some View {
        ZStack{
            if setting.currentLives > 0 // end game
            {
            VStack{
                HStack{// background animation
                    Image("hand")
                        .resizable()
                        .scaledToFit()
                        .scaleEffect(x: -1)
                        .rotationEffect(Angle(degrees: appear ? 45 : 0))
                        .animation(.easeOut(duration: 2).repeatForever(autoreverses: true),value : appear) //animation for waving hand, let and right
                        .onAppear {
                            appear = true
                        }
                    Spacer()
                    Image("hand")
                        .resizable()
                        .scaledToFit()
                        .scaleEffect(x: 1)
                        .rotationEffect(Angle(degrees: appear ? -45 : 0))
                        .animation(.easeOut(duration: 2).repeatForever(autoreverses: true),value : appear)
                        .onAppear {
                            appear = true
                        }
                }
                Spacer()
            }
            VStack{ // game viewplay
                    Text("LIVES : \(setting.currentLives)").font(.custom("Sol Schori Bold", size: 30)).padding(10) //set lives // lives display
                    HStack {
                        Image("Coins")
                        Text("Coins : \(setting.win)").font(.custom("Sol Schori Bold", size: 18)).padding(5) // coins display
                    }
                    Text("\(setting.conditionSignBigger ? ">" : "<") \(setting.conditionWinning)").font(.custom("Sol Schori Bold", size: 18)).padding(5)// challenge display
                    HStack{
                        Image("\(setting.left_die)").resizable().scaledToFit().frame(width: 120).padding(10) // rolling dice
                        Image("\(setting.right_die)").resizable().scaledToFit().frame(width: 120).padding(10)
                    }
                Text("Rerolls : \(setting.rerolls)").font(.custom("Sol Schori Bold", size: 18)).padding(5)// for rerolling  count
                    HStack{
                        Button{ // button of rolling dice
                            setting.roll()
                            Sounds.play(sound: "dice-142528", type: "mp3", loop: 0)//dice sound
                        }label:{
                            Text("Roll").font(.custom("Sol Schori Bold", size: 18))
                                .padding(10)
                        }.buttonStyle(.plain)
                        
                        
                        Button{ // for checking if player win or not
                            setting.check_win_condition() // check win
                            setting.setWinCondition() // set new condition and dice roll for balance
                            setting.roll()
                            Sounds.play(sound: "powerupselect", type: "mp3", loop: 0)// play check sound, power select
                        }label:{
                            Text("Check").font(.custom("Sol Schori Bold", size: 18))
                                .padding(10)
                        }
                        
                    }.buttonStyle(.plain)
            }.onAppear{
                Sounds.play(sound: "GamePlay", type: "mp3", loop: -1)//background song
            }
                
            }else{
                DeathView(setting: setting)// default view
            }
        }
            
    }
}
