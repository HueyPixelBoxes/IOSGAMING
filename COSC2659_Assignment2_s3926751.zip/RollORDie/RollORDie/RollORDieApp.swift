//
//  RollORDieApp.swift
//  RollORDie
//
//  Created by Huy Pham Quang on 29/08/2023.
//

import SwiftUI

@main
struct RollORDieApp: App {
    var body: some Scene {
        WindowGroup {
            MenuView()
        }
    }
}
