//
//  Player.swift
//  RollORDie
//
//  Created by Huy Pham Quang on 05/09/2023.
//
/* RMIT University Vietnam Course: COSC2659 iOS Development
 Semester: 2023B
 Assessment: Assignment 2
 Author: Pham Quang Huy
 ID: s3926751
 Created date: 1/9/2023
 Last modified: 7/9/2023
 Acknowledgement: Courses' lectures & tutorials, minor details from online resources from stackoverflow.com, hackingwithswift.com, ... etc
 */
import Foundation

class Player{ // for saving data as player object inclduing their username, score - coins, achivement game and statistic
    var name : String
    var high_score : Int
    var achivement : String
    var game_played : Int
    var win_percent : Int
    var double_dice : Int
    
    init(name: String, high_score: Int, achivement: String, game_played: Int, win_percent: Int, double_dice: Int) {
        self.name = name
        self.high_score = high_score
        self.achivement = achivement
        self.game_played = game_played
        self.win_percent = win_percent
        self.double_dice = double_dice
    }
}
