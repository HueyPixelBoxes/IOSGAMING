import Foundation
/* RMIT University Vietnam Course: COSC2659 iOS Development
 Semester: 2023B
 Assessment: Assignment 2
 Author: Pham Quang Huy
 ID: s3926751
 Created date: 1/9/2023
 Last modified: 7/9/2023
 Acknowledgement: Courses' lectures & tutorials, minor details from online resources from stackoverflow.com, hackingwithswift.com, ... etc
 */
class GameViewModel : ObservableObject{ // the object for handling logic in GameView
    @Published var left_die = 1 // the dice
    @Published var right_die = 1
    @Published var win = 0 // the coins - high score
    @Published var conditionWinning = 0 // for creating challenge for player to overcome
    @Published var conditionSignBigger = false // randomize the challenge with conditionWinning
    
    @Published var maxLives = 0 // most lives you can have
    @Published var currentLives = 0 // current lives of player
    
    @Published var diff_name = "" // name of the difficulty player select
    var upper_limit = 0 // limits of the value conditionWinning can be for difficulty tweak
    var lower_limit = 0
    @Published var rerolls : Int = 0 // reroll count
    @Published var maxRerolls : Int = 0 // most reroll allowed

    func settingCreate(settingName: String){ // create setting when called from the game -> set the game difficulty
        self.diff_name = settingName // name for setting - difficulties
        switch settingName{
            case "Childplay":
                self.upper_limit = 10
                self.lower_limit = 4
                self.maxLives = 7 // lives for losing a game
                self.rerolls = 7 // to select a dice and reroll dice
            case "Gambler":
                self.upper_limit = 12
                self.lower_limit = 2
                self.maxLives = 5
                self.rerolls = 5
            default:
                self.upper_limit = 11
                self.lower_limit = 3
                self.maxLives = 6
                self.rerolls = 6
        }
        self.currentLives = self.maxLives
        self.maxRerolls = self.rerolls
        self.setWinCondition() // initialize first condition
    }
    
    func setWinCondition(){ // create challenge for player to earn coin
        self.conditionSignBigger = Bool.random()
        self.conditionWinning = Int.random(in: self.lower_limit ... self.upper_limit)
    }
    
    func roll(){ // roll the dice, cost rerolls
        if(self.rerolls > 1){
            self.left_die = Int.random(in: 1...6)
            self.right_die = Int.random(in: 1...6)
            self.rerolls -= 1;
        }else{
            self.rerolls = 0
        }
    }
    
    func check_win_condition(){ // checking if player win. if win, gain coin based on performance, else lose health
        let total = (self.left_die + self.right_die) // dice value
        if(self.conditionSignBigger && total >= self.conditionWinning) // checking if we pass challenge
        {
            Sounds.play(sound: "pickupCoin", type: "mp3", loop: 0) // play sound effect
            self.win += (self.rerolls * abs(total - self.conditionWinning)) // get coin
            self.rerolls = maxRerolls // refill rerolls
        }
        else if (!self.conditionSignBigger && total <= self.conditionWinning)
        {
            Sounds.play(sound: "pickupCoin", type: "mp3", loop: 0)
            self.win += (self.rerolls * abs(total - self.conditionWinning))
            self.rerolls = maxRerolls
        }
        else
        {
            Sounds.play(sound: "hitHurt", type: "mp3", loop: 0)//play sound when hurt
            self.currentLives -= 1 // lose health
        }
    }

    
}





